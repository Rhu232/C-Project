﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class DataAccessLayer
    {
        static string connstring = "Data Source=DESKTOP-I53NE2S\\SQLEXPRESS;Initial Catalog=ProjectDB;Integrated Security=True";
        SqlConnection dbconn = new SqlConnection(connstring);
        SqlCommand dbcomm;
        SqlDataAdapter dbAdapter;
        DataTable dt;

        public int InsertPropertyType(PropertyType propertyType)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_InsertPropertyType", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("@PropertyTypeDescription", propertyType.PropertyTypeDescription);
            int x = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return x;
        }
        public DataTable GetPropertyType()
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_GetPropertyType", dbconn);
            dbAdapter = new SqlDataAdapter(dbcomm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbconn.Close();
            return dt;
        }
        public int InsertProperty(Property property)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_InsertProperty", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("@Description", property.Description);
            dbcomm.Parameters.AddWithValue("@Price", property.Price);
            dbcomm.Parameters.AddWithValue("@Image", property.Image);
            dbcomm.Parameters.AddWithValue("@PropertyTypeID", property.PropertyTypeID);
            dbcomm.Parameters.AddWithValue("@Status", property.Status);
            dbcomm.Parameters.AddWithValue("@SurbubID", property.SurbubID);
            int x = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return x;
        }
        public int UpdateProperty(Property property)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_UpdateProperty", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("@Price", property.Price);
            dbcomm.Parameters.AddWithValue("@PropertyTypeID", property.PropertyTypeID);
            dbcomm.Parameters.AddWithValue("@Status", property.Status);
            int x = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return x;
        }
        public int DeleteProperty(Property property)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_DeleteProperty", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("@PropertyID", property.PropertyTypeID);
            int x = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return x;
        }
        public DataTable GetProperty()
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_GetProperty", dbconn);
            dbAdapter = new SqlDataAdapter(dbcomm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbconn.Close();
            return dt;
        }
        public int InsertProvince(Province province)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_InsertProvince", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("@Description", province.Description);

            int x = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return x;
        }
        public DataTable GetProvice()
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_GetProvice", dbconn);
            dbAdapter = new SqlDataAdapter(dbcomm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbconn.Close();
            return dt;
        }
        public int InsertCity(City city)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_InsertCity", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("@CityDescription", city.CityDescription);
            dbcomm.Parameters.AddWithValue("@ProcinceID", city.ProvinceID);

            int x = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return x;
        }
        public DataTable GetCity()
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_GetCity", dbconn);
            dbAdapter = new SqlDataAdapter(dbcomm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbconn.Close();
            return dt;
        }
        public int InsertSurbub(Surbub surbub)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_InsertSurbub", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("@SurbubDescription", surbub.SurbubDescription);
            dbcomm.Parameters.AddWithValue("@PostalCode", surbub.postalCode);
            dbcomm.Parameters.AddWithValue("@CityID", surbub.CityID);

            int x = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return x;
        }
        public DataTable GetSurbub()
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_GetSurbub", dbconn);
            dbAdapter = new SqlDataAdapter(dbcomm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbconn.Close();
            return dt;
        }
        public int InsertAgency(Agency agency)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_InsertCity", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("@AgencyName", agency.AgencyName);
            dbcomm.Parameters.AddWithValue("@SurbubID", agency.SurbubID);

            int x = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return x;
        }
        public int DeleteAgency(Agency agency)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_DeleteAgency", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("@AgencyID", agency.AgencyID);
            int x = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return x;
        }
        public DataTable GetAgency()
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_GetAgency", dbconn);
            dbAdapter = new SqlDataAdapter(dbcomm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbconn.Close();
            return dt;
        }
        public int InsertAgent(Agent agent)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_InsertAgent", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("@Name", agent.Name);
            dbcomm.Parameters.AddWithValue("@Surname", agent.Surname);
            dbcomm.Parameters.AddWithValue("@Email", agent.Email);
            dbcomm.Parameters.AddWithValue("@Password", agent.Password);
            dbcomm.Parameters.AddWithValue("@Phone", agent.Phone);
            dbcomm.Parameters.AddWithValue("@Status", agent.Status);
            dbcomm.Parameters.AddWithValue("@AgencyID", agent.AgencyID);

            int x = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return x;
        }
        public int UpdateAgent(Agent agent)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_InsertAgent", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("@Email", agent.Email);
            dbcomm.Parameters.AddWithValue("@Phone", agent.Phone);
            dbcomm.Parameters.AddWithValue("@Status", agent.Status);

            int x = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return x;
        }
        public int DeleteAgent(Agent agent)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_DeleteAgency", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("@AgentID", agent.AgentID);
            int x = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return x;
        }
        public DataTable GetAgent()
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_GetAgent", dbconn);
            dbAdapter = new SqlDataAdapter(dbcomm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbconn.Close();
            return dt;
        }
        public int InsertTenant(Tenant tenant)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_InsertTenant", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("@Name", tenant.Name);
            dbcomm.Parameters.AddWithValue("@Surname", tenant.Surname);
            dbcomm.Parameters.AddWithValue("@Email", tenant.Email);
            dbcomm.Parameters.AddWithValue("@Password", tenant.Password);
            dbcomm.Parameters.AddWithValue("@Phone", tenant.Phone);
            dbcomm.Parameters.AddWithValue("@Status", tenant.Status);

            int x = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return x;
        }
        public int UpdateTenant(Tenant tenant)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_InsertAgent", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("@Email", tenant.Email);
            dbcomm.Parameters.AddWithValue("@Phone", tenant.Phone);
            dbcomm.Parameters.AddWithValue("@Status", tenant.Status);

            int x = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return x;
        }
        public int DeleteTenant(Tenant tenant)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_DeleteTenant", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("@TenantID", tenant.TenantID);
            int x = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return x;
        }
        public DataTable GetTenant()
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_GetTenant", dbconn);
            dbAdapter = new SqlDataAdapter(dbcomm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbconn.Close();
            return dt;
        }
        public int InsertPropertyAgent(PropertyAgent propertyAgent)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_InsertPropertyAgent", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("@PropertyID", propertyAgent.PropertyID);
            dbcomm.Parameters.AddWithValue("@AgentID", propertyAgent.AgentID);
            dbcomm.Parameters.AddWithValue("@Date", propertyAgent.Date);


            int x = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return x;
        }
        public int UpdatePropertyAgent(PropertyAgent propertyAgent)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_UpdatePropertyAgent", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("@PropertyID", propertyAgent.PropertyID);
            dbcomm.Parameters.AddWithValue("@AgentID", propertyAgent.AgentID);
            dbcomm.Parameters.AddWithValue("@Date", propertyAgent.Date);


            int x = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return x;
        }
        public DataTable GetPropertyAgent()
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_GetPropertyAgent", dbconn);
            dbAdapter = new SqlDataAdapter(dbcomm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbconn.Close();
            return dt;
        }
        public int InsertRental(Rental rental)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_InsertRental", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("@PropertyAgentID", rental.PropertyAgentID);
            dbcomm.Parameters.AddWithValue("@TenantID", rental.TenantID);
            dbcomm.Parameters.AddWithValue("@StartDate", rental.StartDate);
            dbcomm.Parameters.AddWithValue("@EndDate", rental.EndDate);


            int x = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return x;
        }
        public int UpdateRental(Rental rental)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_InsertRental", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("@StartDate", rental.StartDate);
            dbcomm.Parameters.AddWithValue("@EndDate", rental.EndDate);


            int x = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return x;
        }
        public DataTable GetRental()
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_GetRental", dbconn);
            dbAdapter = new SqlDataAdapter(dbcomm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbconn.Close();
            return dt;
        }
        public DataTable LoginTenant(string Email, string Password)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_LoginTenant", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("Email", Email);
            dbcomm.Parameters.AddWithValue("Password", Password);
            dbAdapter = new SqlDataAdapter(dbcomm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbconn.Close();
            return dt;
        }
        public DataTable LoginAdmin(string Email, string Password)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_LoginAdmin", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("Email", Email);
            dbcomm.Parameters.AddWithValue("Password", Password);
            dbAdapter = new SqlDataAdapter(dbcomm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbconn.Close();
            return dt;
        }
        public DataTable LoginAgent(string Email, string Password)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_LoginAgent", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("Email", Email);
            dbcomm.Parameters.AddWithValue("Password", Password);
            dbAdapter = new SqlDataAdapter(dbcomm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbconn.Close();
            return dt;
        }
        public int InsertAdmin(Admin admin)
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_InsertAdmin", dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;
            dbcomm.Parameters.AddWithValue("@Name", admin.Name);
            dbcomm.Parameters.AddWithValue("@Surname", admin.Surname);
            dbcomm.Parameters.AddWithValue("@Email", admin.Email);
            dbcomm.Parameters.AddWithValue("@Password", admin.Password);
            dbcomm.Parameters.AddWithValue("@Status", admin.Status);
            dbcomm.Parameters.AddWithValue("@TenantID", admin.TenantID);

            int x = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return x;
        }
        public DataTable GetAdmin()
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_GetAdmin", dbconn);
            dbAdapter = new SqlDataAdapter(dbcomm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbconn.Close();
            return dt;
        }
        public DataTable GetAgentt()
        {
            dbconn.Open();
            dbcomm = new SqlCommand("sp_GetAngett", dbconn);
            dbAdapter = new SqlDataAdapter(dbcomm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbconn.Close();
            return dt;
        }
        public int SoftAgent(int agentID)
        {
            dbconn.Open();

            string sql = "sp_GetSoftAgent";
            dbcomm = new SqlCommand(sql, dbconn);
            dbcomm.CommandType = CommandType.StoredProcedure;

            dbcomm.Parameters.AddWithValue("@AgentID", agentID);

            int c = dbcomm.ExecuteNonQuery();
            dbconn.Close();
            return c;
        }

    }
}
