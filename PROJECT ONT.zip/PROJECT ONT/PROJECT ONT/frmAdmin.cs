﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using DAL;
using BLL;

namespace PROJECT_ONT
{
    public partial class frmAdmin : Form
    {
        public frmAdmin()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void frmAdmin_Load(object sender, EventArgs e)
        {
            cmbTenantID.DataSource = bll.GetTenant();
            cmbTenantID.DisplayMember = "Name";
            cmbTenantID.ValueMember = "TenantID";
            
            

            cmbStatus.Items.Add("Available");
            cmbStatus.Items.Add(" Not Available");
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            Admin admin = new Admin();
            txtID.Visible = false;
            admin.Name = txtName.Text;
            admin.Surname = txtSurname.Text;
            admin.Email = txtEmail.Text;
            admin.Password = txtPassword.Text;
            admin.Status = cmbStatus.SelectedItem.ToString();
            admin.TenantID = int.Parse(cmbTenantID.SelectedValue.ToString());
            int x = bll.insertAdmin(admin);
            if (x > 0)
            {
                MessageBox.Show(x + " Added.");
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvAdmin.DataSource = bll.GetAdmin();
        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtEmail.Text) || (!Regex.IsMatch(txtEmail.Text, @"^([\w\.\-]+)@([\w\-]+)((\.(w){2.3})+)$")))
                {
                errorEmail.SetError(txtEmail, "Please enter an email address");
            
                }
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(txtPassword.Text)||(!Regex.IsMatch(txtPassword.Text, @"(\d{8})?$"))) 
            {
                errorPassword.SetError(txtPassword, "Please enter a password");
            }
        }
    }
}
