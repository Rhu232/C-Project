﻿
namespace PROJECT_ONT
{
    partial class ucPropertyType
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPropertytypeID = new System.Windows.Forms.TextBox();
            this.txtPropertytypedesc = new System.Windows.Forms.TextBox();
            this.dgvPropertyT = new System.Windows.Forms.DataGridView();
            this.btnInsrt = new System.Windows.Forms.Button();
            this.btnDisplay = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPropertyT)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Property Type ID:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(28, 63);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Property Type Description:";
            // 
            // txtPropertytypeID
            // 
            this.txtPropertytypeID.Location = new System.Drawing.Point(185, 11);
            this.txtPropertytypeID.Name = "txtPropertytypeID";
            this.txtPropertytypeID.Size = new System.Drawing.Size(126, 20);
            this.txtPropertytypeID.TabIndex = 2;
            // 
            // txtPropertytypedesc
            // 
            this.txtPropertytypedesc.Location = new System.Drawing.Point(185, 55);
            this.txtPropertytypedesc.Name = "txtPropertytypedesc";
            this.txtPropertytypedesc.Size = new System.Drawing.Size(126, 20);
            this.txtPropertytypedesc.TabIndex = 3;
            // 
            // dgvPropertyT
            // 
            this.dgvPropertyT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPropertyT.Location = new System.Drawing.Point(31, 125);
            this.dgvPropertyT.Name = "dgvPropertyT";
            this.dgvPropertyT.Size = new System.Drawing.Size(280, 86);
            this.dgvPropertyT.TabIndex = 4;
            // 
            // btnInsrt
            // 
            this.btnInsrt.Location = new System.Drawing.Point(145, 96);
            this.btnInsrt.Name = "btnInsrt";
            this.btnInsrt.Size = new System.Drawing.Size(75, 23);
            this.btnInsrt.TabIndex = 5;
            this.btnInsrt.Text = "ADD";
            this.btnInsrt.UseVisualStyleBackColor = true;
            this.btnInsrt.Click += new System.EventHandler(this.btnInsrt_Click);
            // 
            // btnDisplay
            // 
            this.btnDisplay.Location = new System.Drawing.Point(236, 96);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(75, 23);
            this.btnDisplay.TabIndex = 6;
            this.btnDisplay.Text = "DISPLAY";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
            // 
            // ucPropertyType
            // 
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.btnInsrt);
            this.Controls.Add(this.dgvPropertyT);
            this.Controls.Add(this.txtPropertytypedesc);
            this.Controls.Add(this.txtPropertytypeID);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Name = "ucPropertyType";
            this.Size = new System.Drawing.Size(334, 232);
            this.Load += new System.EventHandler(this.ucPropertyType_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPropertyT)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button bnDisplay;
        private System.Windows.Forms.Button btnADD;
        private System.Windows.Forms.TextBox txtDesc;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvpropertyType;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtPropertytypeID;
        private System.Windows.Forms.TextBox txtPropertytypedesc;
        private System.Windows.Forms.DataGridView dgvPropertyT;
        private System.Windows.Forms.Button btnInsrt;
        private System.Windows.Forms.Button btnDisplay;
    }
}
