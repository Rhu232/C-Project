﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;

namespace PROJECT_ONT
{
    public partial class ucCity : UserControl
    {
        public ucCity()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void ucCity_Load(object sender, EventArgs e)
        {
            cmbProvince.DataSource = bll.GetProvice();
            
            cmbProvince.ValueMember = "ProvinceID";
            cmbProvince.DisplayMember = "Description";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            City city = new City();
            txtID.Visible = false;
            city.CityDescription = txtDesciption.Text;
            city.ProvinceID = int.Parse(cmbProvince.SelectedValue.ToString());
            int x = bll.InsertCity(city);
            if (x > 0)
            {
                MessageBox.Show(x + "Added");
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvCity.DataSource = bll.GetCity();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
