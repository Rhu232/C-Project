﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using DAL;
using BLL;

namespace PROJECT_ONT
{
    public partial class frmTenent : Form
    {
        public frmTenent()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void dgvTenant_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvTenant.SelectedRows.Count > 0)
            {
                txtName.Text = dgvTenant.SelectedRows[0].Cells["Name"].Value.ToString();
                txtSurname.Text = dgvTenant.SelectedRows[0].Cells["Surname"].Value.ToString();
                txtEmail.Text = dgvTenant.SelectedRows[0].Cells["Email"].Value.ToString();
                txtPassword.Text = dgvTenant.SelectedRows[0].Cells["Password"].Value.ToString();
                txtPhone.Text = dgvTenant.SelectedRows[0].Cells["Phone"].Value.ToString();
                cmbStatus.Text = dgvTenant.SelectedRows[0].Cells["Status"].Value.ToString();
            }
        }
        
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Tenant tenant = new Tenant();
            tenant.Email = txtEmail.Text;
            tenant.Phone = txtPhone.Text;
            tenant.Status = cmbStatus.SelectedItem.ToString();
            int x = bll.UpdateTenant(tenant);
            if (x > 0)
            {
                MessageBox.Show(x + " Updated.");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Tenant tenant = new Tenant();
            txtTenantID.Visible = false;
            tenant.Name = txtName.Text;
            tenant.Surname = txtSurname.Text;
            tenant.Email = txtEmail.Text;
            tenant.Password = txtPassword.Text;
            tenant.Phone = txtPhone.Text;
            tenant.Status = cmbStatus.SelectedItem.ToString();
            int x = bll.InsertTenant(tenant);
            if (x > 0)
            {
                MessageBox.Show(x + " Added.");
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvTenant.DataSource = bll.GetTenant();
        }

        private void frmTenent_Load(object sender, EventArgs e)
        {
            cmbStatus.Items.Add("Available");
            cmbStatus.Items.Add("Not Available");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Tenant tenant = new Tenant();
            tenant.TenantID = int.Parse(txtTenantID.Text);
            int x = bll.DeleteTenant(tenant);
            if (x > 0)
            {
                MessageBox.Show(x + "Deleted.");
            }
        }

        private void txtTenantID_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtEmail.Text) || (!Regex.IsMatch(txtEmail.Text, @"^([\w\.\-]+)@([\w\-]+)((\.(w){2.3})+)$")))
            {
                errorEmail.SetError(txtEmail, "Please enter an email address");

            }
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPassword.Text) || (!Regex.IsMatch(txtPassword.Text, @"(\d{8})?$")))
            {
                errorPassword.SetError(txtPassword, "Please enter a password");
            }
        }
    }
}
