﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DAL;

namespace PROJECT_ONT
{
    public partial class ucPropertyType : UserControl
    {
        public ucPropertyType()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
      

        private void ucPropertyType_Load(object sender, EventArgs e)
        {

        }

        private void btnInsrt_Click(object sender, EventArgs e)
        {
            PropertyType propertyType = new PropertyType();
            txtID.Visible = false;
            propertyType.PropertyTypeDescription = txtPropertytypedesc.Text;

            int x = bll.InsertPropertyType(propertyType);
            if (x > 0)
            {
                MessageBox.Show(x + "Added");
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvPropertyT.DataSource = bll.GetPropertyType();
        }
    }
}
