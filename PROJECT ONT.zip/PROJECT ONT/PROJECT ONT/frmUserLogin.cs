﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;

namespace PROJECT_ONT
{
    public partial class frmUserLogin : Form
    {
        public frmUserLogin()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void UserLogin_Load(object sender, EventArgs e)
        {
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            DataTable dtAdmin = bll.LoginAdmin(txtusername.Text, txtPassword.Text);
            DataTable dtAgent = bll.LoginAgent(txtusername.Text, txtPassword.Text);
            DataTable dtTenant = bll.LoginTenant(txtusername.Text, txtPassword.Text);
            //int result = dtAdmin.TableName;
            //int RESULT = dtAgent.Rows.Count;
            //int output = dtTenant.Columns.Count;

            //if (dt.Rows.Count > 0)
            //{
                if (dtAdmin.Rows.Count>0)
                {
                    //if (dtAdmin.Rows.Count > 0)
                    //{
                        frmAdmin admin = new frmAdmin();
                        admin.Show();
                        this.Hide();


                    //}
                }
               else  if (dtAgent.Rows.Count>0)
                {
                    //if (dtAgent.Rows.Count > 0)
                    //{
                        frmAgent agent = new frmAgent();
                        agent.Show();
                        this.Hide();
                    //}
                }
                //if (dt.Rows[0].ToString() == "sp_LoginTenant")
                //{
                   else if (dtTenant.Rows.Count>0)
                    {
                        frmTenent tenent = new frmTenent();
                        tenent.Show();
                        this.Hide();
                    }
                //}

                else
                {
                    txtusername.Clear();
                    txtPassword.Clear();

                    MessageBox.Show("Incorrect usernamr or password");
                }


        }

    }
            
        
    //}
}
