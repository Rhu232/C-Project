﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;

namespace PROJECT_ONT
{
    public partial class ucAgency : UserControl
    {
        public ucAgency()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void btnAdd_Click(object sender, EventArgs e)
        {
            Agency agency = new Agency();
            txtID.Visible = false;
            agency.AgencyName = txtDesciption.Text;
            agency.SurbubID = int.Parse(cmbSurbub.SelectedValue.ToString());
            int x = bll.InsertAgency(agency);
            if (x > 0)
            {
                MessageBox.Show(x + "Added");
            }
        }

        private void ucAgency_Load(object sender, EventArgs e)
        {

           cmbSurbub.DataSource = bll.GetSurbub();

            
            cmbSurbub.DisplayMember = "SurbubDescription";
            cmbSurbub.ValueMember = "SurbubID";
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvAgency.DataSource = bll.GetAgency();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Agency agency = new Agency();
            txtID.Visible = true;
            agency.AgencyID =int.Parse(txtID.Text);
            
            int x = bll.InsertAgency(agency);
            if (x > 0)
            {
                MessageBox.Show(x + "deleted");
            }
        }
    }
}
