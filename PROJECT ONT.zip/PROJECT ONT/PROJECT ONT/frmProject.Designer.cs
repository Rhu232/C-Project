﻿
namespace PROJECT_ONT
{
    partial class frmProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPropertyType = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ucCity2 = new PROJECT_ONT.ucCity();
            this.ucSuburb1 = new PROJECT_ONT.ucSuburb();
            this.ucAgency1 = new PROJECT_ONT.ucAgency();
            this.ucProvince2 = new PROJECT_ONT.ucProvince();
            this.property1cs2 = new PROJECT_ONT.ucProperty();
            this.btnRental = new System.Windows.Forms.Button();
            this.btnPropertyAgent = new System.Windows.Forms.Button();
            this.btnAgency = new System.Windows.Forms.Button();
            this.btnSurbub = new System.Windows.Forms.Button();
            this.btnCity = new System.Windows.Forms.Button();
            this.btnProvince = new System.Windows.Forms.Button();
            this.btnPropety = new System.Windows.Forms.Button();
            this.ucPropertyType1 = new PROJECT_ONT.ucPropertyType();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnPropertyType
            // 
            this.btnPropertyType.Location = new System.Drawing.Point(33, 52);
            this.btnPropertyType.Margin = new System.Windows.Forms.Padding(4);
            this.btnPropertyType.Name = "btnPropertyType";
            this.btnPropertyType.Size = new System.Drawing.Size(150, 28);
            this.btnPropertyType.TabIndex = 0;
            this.btnPropertyType.Text = "PropertyType";
            this.btnPropertyType.UseVisualStyleBackColor = true;
            this.btnPropertyType.Click += new System.EventHandler(this.btnPropertyType_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ucPropertyType1);
            this.groupBox1.Controls.Add(this.ucCity2);
            this.groupBox1.Controls.Add(this.ucSuburb1);
            this.groupBox1.Controls.Add(this.ucAgency1);
            this.groupBox1.Controls.Add(this.ucProvince2);
            this.groupBox1.Controls.Add(this.property1cs2);
            this.groupBox1.Controls.Add(this.btnRental);
            this.groupBox1.Controls.Add(this.btnPropertyAgent);
            this.groupBox1.Controls.Add(this.btnAgency);
            this.groupBox1.Controls.Add(this.btnSurbub);
            this.groupBox1.Controls.Add(this.btnCity);
            this.groupBox1.Controls.Add(this.btnProvince);
            this.groupBox1.Controls.Add(this.btnPropety);
            this.groupBox1.Controls.Add(this.btnPropertyType);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(32, 15);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(1118, 553);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // ucCity2
            // 
            this.ucCity2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ucCity2.Location = new System.Drawing.Point(311, 34);
            this.ucCity2.Name = "ucCity2";
            this.ucCity2.Size = new System.Drawing.Size(466, 317);
            this.ucCity2.TabIndex = 15;
            // 
            // ucSuburb1
            // 
            this.ucSuburb1.Location = new System.Drawing.Point(311, 25);
            this.ucSuburb1.Name = "ucSuburb1";
            this.ucSuburb1.Size = new System.Drawing.Size(394, 326);
            this.ucSuburb1.TabIndex = 14;
            // 
            // ucAgency1
            // 
            this.ucAgency1.Location = new System.Drawing.Point(336, 138);
            this.ucAgency1.Name = "ucAgency1";
            this.ucAgency1.Size = new System.Drawing.Size(388, 394);
            this.ucAgency1.TabIndex = 13;
            // 
            // ucProvince2
            // 
            this.ucProvince2.Location = new System.Drawing.Point(350, 138);
            this.ucProvince2.Name = "ucProvince2";
            this.ucProvince2.Size = new System.Drawing.Size(440, 454);
            this.ucProvince2.TabIndex = 12;
            // 
            // property1cs2
            // 
            this.property1cs2.Location = new System.Drawing.Point(336, 52);
            this.property1cs2.Name = "property1cs2";
            this.property1cs2.Size = new System.Drawing.Size(493, 533);
            this.property1cs2.TabIndex = 10;
            // 
            // btnRental
            // 
            this.btnRental.Location = new System.Drawing.Point(33, 328);
            this.btnRental.Name = "btnRental";
            this.btnRental.Size = new System.Drawing.Size(150, 23);
            this.btnRental.TabIndex = 9;
            this.btnRental.Text = "Rental";
            this.btnRental.UseVisualStyleBackColor = true;
            // 
            // btnPropertyAgent
            // 
            this.btnPropertyAgent.Location = new System.Drawing.Point(33, 290);
            this.btnPropertyAgent.Name = "btnPropertyAgent";
            this.btnPropertyAgent.Size = new System.Drawing.Size(150, 23);
            this.btnPropertyAgent.TabIndex = 8;
            this.btnPropertyAgent.Text = "Property Agent";
            this.btnPropertyAgent.UseVisualStyleBackColor = true;
            this.btnPropertyAgent.Click += new System.EventHandler(this.btnPropertyAgent_Click);
            // 
            // btnAgency
            // 
            this.btnAgency.Location = new System.Drawing.Point(33, 261);
            this.btnAgency.Name = "btnAgency";
            this.btnAgency.Size = new System.Drawing.Size(150, 23);
            this.btnAgency.TabIndex = 5;
            this.btnAgency.Text = "Agency";
            this.btnAgency.UseVisualStyleBackColor = true;
            this.btnAgency.Click += new System.EventHandler(this.btnAgency_Click);
            // 
            // btnSurbub
            // 
            this.btnSurbub.Location = new System.Drawing.Point(33, 220);
            this.btnSurbub.Name = "btnSurbub";
            this.btnSurbub.Size = new System.Drawing.Size(150, 23);
            this.btnSurbub.TabIndex = 4;
            this.btnSurbub.Text = "Surbub";
            this.btnSurbub.UseVisualStyleBackColor = true;
            this.btnSurbub.Click += new System.EventHandler(this.btnSurbub_Click);
            // 
            // btnCity
            // 
            this.btnCity.Location = new System.Drawing.Point(33, 178);
            this.btnCity.Name = "btnCity";
            this.btnCity.Size = new System.Drawing.Size(150, 23);
            this.btnCity.TabIndex = 3;
            this.btnCity.Text = "City";
            this.btnCity.UseVisualStyleBackColor = true;
            this.btnCity.Click += new System.EventHandler(this.btnCity_Click);
            // 
            // btnProvince
            // 
            this.btnProvince.Location = new System.Drawing.Point(33, 138);
            this.btnProvince.Name = "btnProvince";
            this.btnProvince.Size = new System.Drawing.Size(150, 23);
            this.btnProvince.TabIndex = 2;
            this.btnProvince.Text = "Province";
            this.btnProvince.UseVisualStyleBackColor = true;
            this.btnProvince.Click += new System.EventHandler(this.btnProvince_Click);
            // 
            // btnPropety
            // 
            this.btnPropety.Location = new System.Drawing.Point(33, 96);
            this.btnPropety.Name = "btnPropety";
            this.btnPropety.Size = new System.Drawing.Size(150, 23);
            this.btnPropety.TabIndex = 1;
            this.btnPropety.Text = "Property";
            this.btnPropety.UseVisualStyleBackColor = true;
            this.btnPropety.Click += new System.EventHandler(this.btnPropety_Click);
            // 
            // ucPropertyType1
            // 
            this.ucPropertyType1.Location = new System.Drawing.Point(336, 63);
            this.ucPropertyType1.Name = "ucPropertyType1";
            this.ucPropertyType1.Size = new System.Drawing.Size(334, 232);
            this.ucPropertyType1.TabIndex = 16;
            // 
            // frmProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1163, 579);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmProject";
            this.Text = "Project";
            this.Load += new System.EventHandler(this.frmProject_Load);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnPropertyType;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnRental;
        private System.Windows.Forms.Button btnPropertyAgent;
        private System.Windows.Forms.Button btnAgency;
        private System.Windows.Forms.Button btnSurbub;
        private System.Windows.Forms.Button btnCity;
        private System.Windows.Forms.Button btnProvince;
        private System.Windows.Forms.Button btnPropety;
        private ucPropertyAgent ucPropertyAgent1;
        private ucPropertyType propertyType11;
        private ucProperty property1cs1;
        private ucCity ucCity1;
        private ucProvince ucProvince1;
        private ucProvince ucProvince2;
        private ucProperty property1cs2;
        private ucAgency ucAgency1;
        private ucCity ucCity2;
        private ucSuburb ucSuburb1;
        private ucPropertyType ucPropertyType1;
    }
}