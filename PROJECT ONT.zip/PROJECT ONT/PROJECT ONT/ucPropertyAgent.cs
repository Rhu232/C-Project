﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;


namespace PROJECT_ONT
{
    public partial class ucPropertyAgent : UserControl
    {
        public ucPropertyAgent()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void groupBox1_Enter(object sender, EventArgs e)
        {
           
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            PropertyAgent propertyAgent = new PropertyAgent();
            propertyAgent.PropertyAgentID = int.Parse(cmbProperty.SelectedValue.ToString());
            propertyAgent.AgentID = int.Parse(cmbAgent.SelectedValue.ToString());
            propertyAgent.Date = dateTimePicker1.Text;

            int x = bll.InsertProprtyAgent(propertyAgent);
            if (x > 0)
            {
                MessageBox.Show(x + "PropertyAgent Added.");
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvPropertyAgent.DataSource = bll.GetPropertyAgent();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            PropertyAgent propertyAgent = new PropertyAgent();
            propertyAgent.PropertyAgentID = int.Parse(cmbProperty.SelectedValue.ToString());
            propertyAgent.AgentID = int.Parse(cmbAgent.SelectedValue.ToString());
            propertyAgent.Date = dateTimePicker1.Text;

            int x = bll.UpdatePropertyAgent(propertyAgent);
            if (x > 0)
            {
                MessageBox.Show(x + "PropertyAgent Updated.");
            }
        }

        private void dgvPropertyAgent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvPropertyAgent.SelectedRows.Count > 0)
            {

            }
        }

        private void ucPropertyAgent_Load(object sender, EventArgs e)
        {
            cmbProperty.DataSource = bll.GetPropertyAgent();
            cmbProperty.DisplayMember = "Description";
            cmbProperty.ValueMember = "PropertyID";

            cmbAgent.DataSource = bll.GetAgent();
            cmbAgent.DisplayMember = "Name";
            cmbAgent.DisplayMember = "Surname";
            cmbAgent.ValueMember = "AgentID";
        }
    }
}
