﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROJECT_ONT
{
    public partial class frmProject : Form
    {
        public frmProject()
        {
            InitializeComponent();
        }

        private void btnTenant_Click(object sender, EventArgs e)
        {



        }

        private void btnAgent_Click(object sender, EventArgs e)
        {
            

        }

        private void btnPropety_Click(object sender, EventArgs e)
        {
            this.ucPropertyAgent1.Visible = false;
            this.ucAgency1.Visible = false;
            this.ucSuburb1.Visible = false;
            this.ucPropertyType1.Visible = false;
            this.ucCity1.Visible = false;
            this.ucProvince1.Visible = false;
            this.property1cs1.BringToFront();
            this.property1cs1.Visible = true;
        }

        private void btnPropertyType_Click(object sender, EventArgs e)
        {
            this.ucPropertyAgent1.Visible = false;
            this.ucAgency1.Visible = false;
            this.ucSuburb1.Visible = false;
            this.ucPropertyType1.Visible = true;
            this.ucCity1.Visible = false;
            this.ucProvince1.Visible = false;
            this.ucPropertyType1.BringToFront();
            this.property1cs1.Visible = false;
        }

        private void btnCity_Click(object sender, EventArgs e)
        {
            this.ucPropertyAgent1.Visible = false;
            this.ucAgency1.Visible = false;
            this.ucSuburb1.Visible = false;
            this.ucPropertyType1.Visible = false;
            this.ucCity1.Visible = true;
            this.ucProvince1.Visible =false;
            this.ucCity1.BringToFront();
            this.property1cs1.Visible = false;
        }

        private void btnProvince_Click(object sender, EventArgs e)
        {
           
            this.ucAgency1.Visible = false;
            this.ucSuburb1.Visible = false;
            this.ucPropertyType1.Visible = false;
            this.ucCity1.Visible = false;
            this.ucProvince1.Visible = true;
            this.ucProvince1.BringToFront();
            this.property1cs1.Visible = false;
            this.ucPropertyAgent1.Visible = false;
        }

        private void frmProject_Load(object sender, EventArgs e)
        {

        }

        private void btnSurbub_Click(object sender, EventArgs e)
        {
            this.ucPropertyAgent1.Visible = false;
            this.ucSuburb1.BringToFront();
            this.ucSuburb1.Visible = true;
            this.ucPropertyType1.Visible = false;
            this.ucCity1.Visible = false;
            this.ucProvince1.Visible = false;
            this.ucAgency1.Visible = false;
            this.property1cs1.Visible = false;
        }

        private void btnAgency_Click(object sender, EventArgs e)
        {
            this.ucPropertyAgent1.Visible = false;
            this.ucAgency1.BringToFront();
            this.ucAgency1.Visible = true;
            this.ucPropertyType1.Visible = false;
            this.ucCity1.Visible = false;
            this.ucProvince1.Visible = false;
            this.ucSuburb1.Visible = false;
            this.property1cs1.Visible = false;
        }

        private void btnPropertyAgent_Click(object sender, EventArgs e)
        {
            this.ucPropertyAgent1.Visible = true;
            this.ucPropertyAgent1.BringToFront();
            this.ucSuburb1.Visible = false;
            this.ucPropertyType1.Visible = false;
            this.ucCity1.Visible = false;
            this.ucProvince1.Visible = false;
            this.ucAgency1.Visible = false;
            this.property1cs1.Visible = false;
        }
    }
}
