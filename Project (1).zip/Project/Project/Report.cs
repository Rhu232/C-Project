﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Report : Form
    {
        public Report()
        {
            InitializeComponent();
        }

        private void btnRecords_Click(object sender, EventArgs e)
        {

            //ucRecords1.Show();
            //ucRecords1.BringToFront();
            //ucUserType1.Hide();
            //ucAgencies1.Hide();



        }

        private void btnUseType_Click(object sender, EventArgs e)
        {
            //ucUserType1.Show();
            //ucUserType1.BringToFront();
            //ucRecords1.Hide();
            //ucAgencies1.Hide();
            //ucCiProSub1.Hide();



        }

        private void btnAgencies_Click(object sender, EventArgs e)
        {
            //ucAgencies1.Show();
            //ucAgencies1.BringToFront();
            //ucRecords1.Hide();
            //ucUserType1.Hide();
            //ucCiProSub1.Hide();
            //ucOverTime1.Hide();
        }

        private void btnCiProSu_Click(object sender, EventArgs e)
        {
            //ucCiProSub1.Show();
            //ucCiProSub1.BringToFront();
            //ucAgencies1.Hide();
            //ucRecords1.Hide();
            //ucUserType1.Hide();
            //ucOverTime1.Hide();
        }

        private void btnOvertime_Click(object sender, EventArgs e)
        {
            //ucOverTime1.Show();
            //ucOverTime1.BringToFront();
            //ucAgencies1.Hide();
            //ucRecords1.Hide();
            //ucUserType1.Hide();
            //ucCiProSub1.Hide();
        }

        private void btnPpType_Click(object sender, EventArgs e)
        {
            //ucPropType1.Show();
            //ucPropType1.BringToFront();
            //ucAgencies1.Hide();
            //ucRecords1.Hide();
            //ucUserType1.Hide();
            //ucCiProSub1.Hide();
            //ucOverTime1.Hide();
        }

        private void btnEndedDate_Click(object sender, EventArgs e)
        {

        }

        private void Report_Load(object sender, EventArgs e)
        {

        }
    }
}
