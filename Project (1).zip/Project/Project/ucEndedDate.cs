﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DLL;
using BLL;

namespace Project
{
    public partial class ucEndedDate : UserControl
    {
        public ucEndedDate()
        {
            InitializeComponent();
        }

        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            Rental rn = new Rental();
            rn.EndDate = dateTimePicker1.Text;



            dataGridView1.DataSource = bll.EndedDate(rn);

        }
    }
}
