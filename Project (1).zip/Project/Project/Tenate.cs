﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DLL;
using BLL;

namespace Project
{
    public partial class Tenate : Form
    {
        public Tenate()
        {
            InitializeComponent();
        }

        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void btnADD_Click(object sender, EventArgs e)
        {

            Tenant tenant = new Tenant();
            txtID.Visible = false;
            tenant.Name = txtName.Text;
            tenant.Surname = txtSurname.Text;
            tenant.Email = txtEmail.Text;
            tenant.Password = txtPassword.Text;
            tenant.Phone = txtPhone.Text;
            tenant.Status = cmbStatus.SelectedItem.ToString();

            int x = bll.InsertTenant(tenant);
            if (x > 0)
            {
                MessageBox.Show(x + " Added.");
            }

        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {

            dgvTenant.DataSource = bll.GetTenant();

        }

        private void Tenate_Load(object sender, EventArgs e)
        {
            cmbStatus.Items.Add("Available");
            cmbStatus.Items.Add("Not Available");

        }

        private void dgvTenant_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvTenant_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (dgvTenant.SelectedRows.Count > 0)
            {
                txtName.Text = dgvTenant.SelectedRows[0].Cells["Name"].Value.ToString();
                txtSurname.Text = dgvTenant.SelectedRows[0].Cells["Surname"].Value.ToString();
                txtEmail.Text = dgvTenant.SelectedRows[0].Cells["Email"].Value.ToString();
                txtPassword.Text = dgvTenant.SelectedRows[0].Cells["Password"].Value.ToString();
                txtPhone.Text = dgvTenant.SelectedRows[0].Cells["Phone"].Value.ToString();
                cmbStatus.Text = dgvTenant.SelectedRows[0].Cells["Status"].Value.ToString();
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            Tenant tenant = new Tenant();
            tenant.Email = txtEmail.Text;
            tenant.Phone = txtPhone.Text;
            tenant.Status = cmbStatus.SelectedItem.ToString();
            int x = bll.UpdateTenant(tenant);
            if (x > 0)
            {
                MessageBox.Show(x + " Updated.");
            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            Tenant tenant = new Tenant();
            tenant.TenantID = int.Parse(txtID.Text);
            int x = bll.DeleteTenant(tenant);
            if (x > 0)
            {
                MessageBox.Show(x + "Deleted.");
            }

        }
    }
}
