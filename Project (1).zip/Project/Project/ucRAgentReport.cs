﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DLL;
using BLL;

namespace Project
{
    public partial class ucRAgentReport : UserControl
    {
        public ucRAgentReport()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void btnDisplay_Click(object sender, EventArgs e)
        {

            Agent1 agent = new Agent1();
            Tenant tenant = new Tenant();

            agent.Name = txtAgent.Text;
            tenant.Name = txtTenant.Text;
            dgvResponsibleAgent.DataSource = bll.AgentReport(tenant, agent);


        }

        private void dgvResponsibleAgent_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (dgvResponsibleAgent.SelectedRows.Count > 0)
            {
                txtTenant.Text = dgvResponsibleAgent.SelectedRows[0].Cells["@Name"].Value.ToString();
                txtAgent.Text = dgvResponsibleAgent.SelectedRows[0].Cells["@Name"].Value.ToString();
            }

        }
    }
}
