﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DLL;
using BLL;

namespace Project
{
    public partial class ucSurbub : UserControl
    {
        public ucSurbub()
        {
            InitializeComponent();
        }

        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void ucSurbub_Load(object sender, EventArgs e)
        {

            cmbCity.DataSource = bll.GetCity();
            cmbCity.DisplayMember = "CityDescription";
            cmbCity.ValueMember = "CityID";

        }

        private void btnADD_Click(object sender, EventArgs e)
        {

            Surbub surbub = new Surbub();
            surbub.SurbubDescription = txtDesc.Text;
            surbub.PostalCode = int.Parse(txtPostalcode.Text);
            surbub.CityID = int.Parse(cmbCity.SelectedValue.ToString());
            int x = bll.InsertSurbub(surbub);
            if (x > 0)
            {
                MessageBox.Show(x + "Added");
            }

        }

        private void btnDispaly_Click(object sender, EventArgs e)
        {
            dgvSurbub.DataSource = bll.GetSurbub();

        }
    }
}
