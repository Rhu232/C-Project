﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DLL;
using BLL;


namespace Project
{
    public partial class ucRental : UserControl
    {
        public ucRental()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void btnUpdate_Click(object sender, EventArgs e)
        {

        }

        private void btnADD_Click(object sender, EventArgs e)
        {
            Rental rental = new Rental();
            
            rental.StartDate = dateTimePicker1.Text;
            rental.EndDate = dateTimePicker2.Text;

            int x = bll.InsertRental(rental);

         if(x > 0)
            {
                MessageBox.Show(x + "Added");
            }
            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void ucRental_Load(object sender, EventArgs e)
        {
            cmbPropertyAgent.DataSource = bll.GetPropertyAgent();
            cmbPropertyAgent.ValueMember = "PropertyAgent";
            cmbPropertyAgent.DisplayMember = "RentalID";

            cmbTenantID.DataSource = bll.GetTenant();
            cmbTenantID.ValueMember = "TenantID";
            cmbTenantID.DisplayMember = "RentalID";

           

        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvRental.DataSource = bll.GetRental();
        }
    }
}
