﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DLL;
using BLL;

namespace Project
{
    public partial class ucPropType : UserControl
    {
        public ucPropType()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void btnDisplay_Click(object sender, EventArgs e)
        {

            Property prop = new Property();
            PropertyType type = new PropertyType();
            prop.Description = txtProperty.Text;
            type.PropertyTypeDescription = txtPropTy.Text;

            dataGridView1.DataSource = bll.PropType(prop, type);


        }
    }
}
