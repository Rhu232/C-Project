﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DLL;
using BLL;

namespace Project
{
    public partial class ucAgencies : UserControl
    {
        public ucAgencies()
        {
            InitializeComponent();
        }


        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void btnDisplay_Click(object sender, EventArgs e)
        {

            Agency agency = new Agency();
            agency.AgencyName = txtAgencies.Text;

            dgvAgencie.DataSource = bll.GetAgency(agency);



        }
    }
}
