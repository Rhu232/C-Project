﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DLL;
using BLL;

namespace Project
{
    public partial class ucCity : UserControl
    {
        public ucCity()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void ucCity_Load(object sender, EventArgs e)
        {

            cmbProvinceID.DataSource = bll.GetProvice();
            cmbProvinceID.ValueMember = "ProvinceID";
            cmbProvinceID.DisplayMember = "Description";

        }

        private void btnADD_Click(object sender, EventArgs e)
        {

            City city = new City();
            city.CityDescription = txtCityDesc.Text;
            city.ProvinceID = int.Parse(cmbProvinceID.SelectedValue.ToString());
            int x = bll.InsertCity(city);
            if (x > 0)
            {
                MessageBox.Show(x + "Added");
            }


        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {

            dgvCity.DataSource = bll.GetCity();
        }

        private void ucRental1_Load(object sender, EventArgs e)
        {

        }
    }
}
