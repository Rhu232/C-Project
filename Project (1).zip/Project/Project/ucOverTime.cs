﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DLL;
using BLL;

namespace Project
{
    public partial class ucOverTime : UserControl
    {
        public ucOverTime()
        {
            InitializeComponent();
        }


        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void btnDisplay_Click(object sender, EventArgs e)
        {

            Tenant tenant = new Tenant();
            Property prop = new Property();
            Rental rn = new Rental();

            tenant.Name = txtTenat.Text;
            prop.Description = txtProperty.Text;
            rn.EndDate = dateTimePicker1.Text;

            dgvOverT.DataSource = bll.GetOverTime(tenant, prop, rn);

        }
    }
}
