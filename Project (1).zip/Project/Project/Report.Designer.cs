﻿
namespace Project
{
    partial class Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRecords = new System.Windows.Forms.Button();
            this.btnUseType = new System.Windows.Forms.Button();
            this.btnAgencies = new System.Windows.Forms.Button();
            this.btnCiProSu = new System.Windows.Forms.Button();
            this.btnOvertime = new System.Windows.Forms.Button();
            this.btnEndedDate = new System.Windows.Forms.Button();
            this.btnPpType = new System.Windows.Forms.Button();
            this.btnAmount = new System.Windows.Forms.Button();
            this.btnAgentReport = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnRecords
            // 
            this.btnRecords.Location = new System.Drawing.Point(20, 35);
            this.btnRecords.Name = "btnRecords";
            this.btnRecords.Size = new System.Drawing.Size(127, 23);
            this.btnRecords.TabIndex = 0;
            this.btnRecords.Text = "Records";
            this.btnRecords.UseVisualStyleBackColor = true;
            this.btnRecords.Click += new System.EventHandler(this.btnRecords_Click);
            // 
            // btnUseType
            // 
            this.btnUseType.Location = new System.Drawing.Point(20, 81);
            this.btnUseType.Name = "btnUseType";
            this.btnUseType.Size = new System.Drawing.Size(127, 23);
            this.btnUseType.TabIndex = 1;
            this.btnUseType.Text = "User Type";
            this.btnUseType.UseVisualStyleBackColor = true;
            this.btnUseType.Click += new System.EventHandler(this.btnUseType_Click);
            // 
            // btnAgencies
            // 
            this.btnAgencies.Location = new System.Drawing.Point(20, 121);
            this.btnAgencies.Name = "btnAgencies";
            this.btnAgencies.Size = new System.Drawing.Size(127, 23);
            this.btnAgencies.TabIndex = 2;
            this.btnAgencies.Text = "Agencies";
            this.btnAgencies.UseVisualStyleBackColor = true;
            this.btnAgencies.Click += new System.EventHandler(this.btnAgencies_Click);
            // 
            // btnCiProSu
            // 
            this.btnCiProSu.Location = new System.Drawing.Point(20, 165);
            this.btnCiProSu.Name = "btnCiProSu";
            this.btnCiProSu.Size = new System.Drawing.Size(127, 23);
            this.btnCiProSu.TabIndex = 3;
            this.btnCiProSu.Text = "City,Province,Surburb";
            this.btnCiProSu.UseVisualStyleBackColor = true;
            this.btnCiProSu.Click += new System.EventHandler(this.btnCiProSu_Click);
            // 
            // btnOvertime
            // 
            this.btnOvertime.Location = new System.Drawing.Point(20, 205);
            this.btnOvertime.Name = "btnOvertime";
            this.btnOvertime.Size = new System.Drawing.Size(127, 23);
            this.btnOvertime.TabIndex = 4;
            this.btnOvertime.Text = "Display Overtime";
            this.btnOvertime.UseVisualStyleBackColor = true;
            this.btnOvertime.Click += new System.EventHandler(this.btnOvertime_Click);
            // 
            // btnEndedDate
            // 
            this.btnEndedDate.Location = new System.Drawing.Point(20, 247);
            this.btnEndedDate.Name = "btnEndedDate";
            this.btnEndedDate.Size = new System.Drawing.Size(127, 23);
            this.btnEndedDate.TabIndex = 5;
            this.btnEndedDate.Text = "Ended Date";
            this.btnEndedDate.UseVisualStyleBackColor = true;
            this.btnEndedDate.Click += new System.EventHandler(this.btnEndedDate_Click);
            // 
            // btnPpType
            // 
            this.btnPpType.Location = new System.Drawing.Point(20, 297);
            this.btnPpType.Name = "btnPpType";
            this.btnPpType.Size = new System.Drawing.Size(127, 23);
            this.btnPpType.TabIndex = 6;
            this.btnPpType.Text = "Property PropetyType";
            this.btnPpType.UseVisualStyleBackColor = true;
            this.btnPpType.Click += new System.EventHandler(this.btnPpType_Click);
            // 
            // btnAmount
            // 
            this.btnAmount.Location = new System.Drawing.Point(20, 336);
            this.btnAmount.Name = "btnAmount";
            this.btnAmount.Size = new System.Drawing.Size(127, 23);
            this.btnAmount.TabIndex = 7;
            this.btnAmount.Text = "Amounts";
            this.btnAmount.UseVisualStyleBackColor = true;
            // 
            // btnAgentReport
            // 
            this.btnAgentReport.Location = new System.Drawing.Point(20, 384);
            this.btnAgentReport.Name = "btnAgentReport";
            this.btnAgentReport.Size = new System.Drawing.Size(127, 23);
            this.btnAgentReport.TabIndex = 8;
            this.btnAgentReport.Text = "Responsible Agent";
            this.btnAgentReport.UseVisualStyleBackColor = true;
            // 
            // Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnAgentReport);
            this.Controls.Add(this.btnAmount);
            this.Controls.Add(this.btnPpType);
            this.Controls.Add(this.btnEndedDate);
            this.Controls.Add(this.btnOvertime);
            this.Controls.Add(this.btnCiProSu);
            this.Controls.Add(this.btnAgencies);
            this.Controls.Add(this.btnUseType);
            this.Controls.Add(this.btnRecords);
            this.Name = "Report";
            this.Text = "Report";
            this.Load += new System.EventHandler(this.Report_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnRecords;
        private System.Windows.Forms.Button btnUseType;
        private System.Windows.Forms.Button btnAgencies;
        private System.Windows.Forms.Button btnCiProSu;
        private System.Windows.Forms.Button btnOvertime;
        private System.Windows.Forms.Button btnEndedDate;
        private System.Windows.Forms.Button btnPpType;
        private System.Windows.Forms.Button btnAmount;
        private System.Windows.Forms.Button btnAgentReport;
    }
}