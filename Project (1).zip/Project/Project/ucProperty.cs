﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DLL;
using BLL;

namespace Project
{
    public partial class ucProperty : UserControl
    {
        public ucProperty()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void ucProperty_Load(object sender, EventArgs e)
        {
            cmbPropertyType.DataSource = bll.GetPropertyType();

            cmbPropertyType.DisplayMember = "PropertyTypeDescription";
            cmbPropertyType.ValueMember = "PropertyTypeID";

            cmbStatus.Items.Add("Avilable");
            cmbStatus.Items.Add("Unavilable");

            cmbSurbub.DataSource = bll.GetSurbub();
            cmbSurbub.DisplayMember = "SurbubDescription";
            cmbSurbub.ValueMember = "SurbubID";


        }

        private void btnADD_Click(object sender, EventArgs e)
        {

            Property prop = new Property();

            prop.Description = txtDesc.Text;
            prop.Price = txtPrice.Text;
            prop.Image = (txtImage.Text);
            prop.PropertyTypeID = int.Parse(cmbPropertyType.SelectedValue.ToString());
            prop.Status = cmbStatus.SelectedItem.ToString();
            prop.SurbubID = int.Parse(cmbSurbub.SelectedValue.ToString());

            int x = bll.InsertProperty(prop);
            if (x > 0)
            {
                MessageBox.Show(x + "ADDed");
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Property prop = new Property();

            prop.Price = txtPrice.Text;
            prop.PropertyTypeID = int.Parse(cmbPropertyType.SelectedItem.ToString());
            prop.Status = cmbStatus.SelectedItem.ToString();


            int x = bll.UpdateProperty(prop);
            if (x > 0)
            {
                MessageBox.Show(x + "Updated");
            }


        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            Property pt = new Property();

            int x = bll.DeleteProperty(pt);

            if (x > 0)
            {
                MessageBox.Show(x + "Deleted");
            }

        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvProperty.DataSource = bll.GetProperty();
        }

        private void dgvProperty_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (dgvProperty.SelectedRows.Count > 0)
            {
                txtDesc.Text = dgvProperty.SelectedRows[0].Cells["Description"].Value.ToString();
                txtPrice.Text = dgvProperty.SelectedRows[0].Cells["Price"].Value.ToString();
                txtImage.Text = dgvProperty.SelectedRows[0].Cells["Image"].Value.ToString();
                cmbPropertyType.Text = dgvProperty.SelectedRows[0].Cells["PropertyTypeID"].Value.ToString();
                cmbStatus.Text = dgvProperty.SelectedRows[0].Cells["Status"].Value.ToString();
                cmbSurbub.Text = dgvProperty.SelectedRows[0].Cells["SurbubID"].Value.ToString();
            }

        }
    }
}
