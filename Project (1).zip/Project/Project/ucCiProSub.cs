﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DLL;
using BLL;

namespace Project
{
    public partial class ucCiProSub : UserControl
    {
        public ucCiProSub()
        {
            InitializeComponent();
        }


        BusinessLogicLayer bll = new BusinessLogicLayer();
      
        private void ucCiProSub_Load(object sender, EventArgs e)
        {

        }

        private void btnDisplay_Click_1(object sender, EventArgs e)
        {
            City ci = new City();
            Province pro = new Province();
            Surbub sub = new Surbub();

            ci.CityDescription = txtCity.Text;
            pro.Description = txtProvince.Text;
            sub.SurbubDescription = txtSurbub.Text;

            dataGridView1.DataSource = bll.CiProSub(ci, pro, sub);

        }
    }
}
