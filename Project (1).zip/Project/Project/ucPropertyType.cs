﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DLL;
using BLL;

namespace Project
{
    public partial class ucPropertyType : UserControl
    {
        public ucPropertyType()
        {
            InitializeComponent();
        }

        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ucPropertyType_Load(object sender, EventArgs e)
        {

        }

        private void btnADD_Click(object sender, EventArgs e)
        {

            PropertyType propertyType = new PropertyType();
            propertyType.PropertyTypeDescription = txtDesc.Text;

            int x = bll.InsertPropertyType(propertyType);
            if (x > 0)
            {
                MessageBox.Show(x + "Added");
            }

        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {

            dataGridView1.DataSource = bll.GetPropertyType();
        }
    }
}
