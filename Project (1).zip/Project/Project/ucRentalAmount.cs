﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DLL;
using BLL;

namespace Project
{
    public partial class ucRentalAmount : UserControl
    {
        public ucRentalAmount()
        {
            InitializeComponent();
        }

        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void btnDisplay_Click(object sender, EventArgs e)
        {

            Property prop = new Property();
            prop.Price = textBox1.Text;
            dataGridView1.DataSource = bll.Amount(prop);

        }
    }
}
