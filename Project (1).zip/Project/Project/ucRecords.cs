﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DLL;
using BLL;

namespace Project
{
    public partial class ucRecords : UserControl
    {
        public ucRecords()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void btnDisplay_Click(object sender, EventArgs e)
        {
            Admin ad = new Admin();
            Tenant tn = new Tenant();
            Agent1 ag = new Agent1();

            ad.Name = txtAdmin.Text;
            tn.Name = txtTenant.Text;
            ag.Name = txtAgent.Text;

            dataGridView1.DataSource = bll.Records(ad, tn, ag);

        }
    }
}
