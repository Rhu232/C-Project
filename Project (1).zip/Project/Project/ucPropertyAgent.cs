﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DLL;
using BLL;

namespace Project
{
    public partial class ucPropertyAgent : UserControl
    {
        public ucPropertyAgent()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void ucPropertyAgent_Load(object sender, EventArgs e)
        {

            cmbProperty.DataSource = bll.GetPropertyAgent();
            cmbProperty.DisplayMember = "Description";
            cmbProperty.ValueMember = "PropertyID";

            cmbAgent.DataSource = bll.GetAgent();
            cmbAgent.DisplayMember = "Name";
            cmbAgent.DisplayMember = "Surname";
            cmbAgent.ValueMember = "AgentID";


        }

        private void btnADD_Click(object sender, EventArgs e)
        {

            PropertyAgent propertyAgent = new PropertyAgent();
            propertyAgent.PropertyAgentID = int.Parse(cmbProperty.SelectedValue.ToString());
            propertyAgent.AgentID = int.Parse(cmbAgent.SelectedValue.ToString());
            propertyAgent.Date = dateTimePicker1.Text;

            int x = bll.InsertProprtyAgent(propertyAgent);
            if (x > 0)
            {
                MessageBox.Show(x + "PropertyAgent Added.");
            }

        }

        private void btnDispaly_Click(object sender, EventArgs e)
        {

            dgvPropetyAgent.DataSource = bll.GetPropertyAgent();

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            PropertyAgent propertyAgent = new PropertyAgent();
            propertyAgent.PropertyAgentID = int.Parse(cmbProperty.SelectedValue.ToString());
            propertyAgent.AgentID = int.Parse(cmbAgent.SelectedValue.ToString());
            propertyAgent.Date = dateTimePicker1.Text;

            int x = bll.UpdatePropertyAgent(propertyAgent);
            if (x > 0)
            {
                MessageBox.Show(x + "PropertyAgent Updated.");
            }


        }
    }
}
