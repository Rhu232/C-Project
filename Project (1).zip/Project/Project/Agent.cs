﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DLL;

namespace Project
{
    public partial class Agent : Form
    {
        public Agent()
        {
            InitializeComponent();
        }

        private void Agent_Load(object sender, EventArgs e)
        {

            cmbAgencyType.DataSource = bll.GetAgency();
            cmbAgencyType.DisplayMember = "AgencyName";
            cmbAgencyType.ValueMember = "AgencyID";

            cmbStatus.Items.Add("Available");
            cmbStatus.Items.Add("Not Available");

        }

        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void btnADD_Click(object sender, EventArgs e)
        {

            Agent1 agent = new Agent1();
            agent.Name = txtName.Text;
            agent.Surname = txtSurname.Text;
            agent.Email = txtEmail.Text;
            agent.Password = txtPassword.Text;
            agent.Phone = txtPhone.Text;
            agent.Status = cmbStatus.SelectedItem.ToString();
            agent.AgencyID = int.Parse(cmbAgencyType.SelectedValue.ToString());

            int x = bll.InsertAgent(agent);
            if (x > 0)
            {
                MessageBox.Show(x + " Added");
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Agent1 agent = new Agent1();

            agent.Email= txtEmail.Text;
            agent.Phone = txtPhone.Text;
            agent.Status = cmbStatus.SelectedItem.ToString();
            int x = bll.UpdateAgent(agent);
            if (x > 0)
            {
                MessageBox.Show(x + "Agent Updated.");
            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            Agent1 agent = new Agent1();
            agent.Email = txtEmail.Text;
            agent.Phone = txtPhone.Text;
            agent.Status = cmbStatus.SelectedItem.ToString();
            int x = bll.UpdateAgent(agent);
            if (x > 0)
            {
                MessageBox.Show(x + "Agent Updated.");
            }

        }

        private void dgvAgent_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (dgvAgent.SelectedRows.Count > 0)
            {
                txtName.Text = dgvAgent.SelectedRows[0].Cells["Name"].Value.ToString();
                txtSurname.Text = dgvAgent.SelectedRows[0].Cells["Surname"].Value.ToString();
                txtEmail.Text = dgvAgent.SelectedRows[0].Cells["Email"].Value.ToString();
                txtPassword.Text = dgvAgent.SelectedRows[0].Cells["Password"].Value.ToString();
                txtPhone.Text = dgvAgent.SelectedRows[0].Cells["Phone"].Value.ToString();
                cmbStatus.Text = dgvAgent.SelectedRows[0].Cells["Status"].Value.ToString();
                cmbAgencyType.Text = dgvAgent.SelectedRows[0].Cells["AgentID"].Value.ToString();
            }

        }
    }
}
