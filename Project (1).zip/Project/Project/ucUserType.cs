﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DLL;
using BLL;

namespace Project
{
    public partial class ucUserType : UserControl
    {
        public ucUserType()
        {
            InitializeComponent();
        }


        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            Admin admin = new Admin();
            Tenant tenant = new Tenant();
            Agent1 agent = new Agent1();

            agent.AgentID = int.Parse(cmbUserT.Text);
            tenant.TenantID = int.Parse(cmbUserT.Text);
            admin.AdminID = int.Parse(cmbUserT.Text);

            cmbUserT.DataSource = bll.UserType(admin, tenant, agent);
            dgvUserT.DataSource = bll.UserType(admin, tenant, agent);


        }
    }
}
