﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DLL;
using BLL;

namespace Project
{
    public partial class frmAdmin : Form
    {
        public frmAdmin()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void btnADD_Click(object sender, EventArgs e)
        {

            Admin admin = new Admin();
            txtID.Visible = false;
            admin.Name = txtName.Text;
            admin.Surname = txtSurname.Text;
            admin.Email = txtEmail.Text;
            admin.Password = txtPassword.Text;
            admin.Status = cmbStatus.SelectedItem.ToString();
            admin.TenantID = int.Parse(cmbTenantID.SelectedValue.ToString());
            int x = bll.InsertAdmin(admin);
            if (x > 0)
            {
                MessageBox.Show(x + " Added.");
            }

        }

        private void frmAdmin_Load(object sender, EventArgs e)
        {

            cmbTenantID.DataSource = bll.GetTenant();
            cmbTenantID.DisplayMember = "Name";
            cmbTenantID.ValueMember = "TenantID";



            cmbStatus.Items.Add("Available");
            cmbStatus.Items.Add(" Not Available");


        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvAdmin.DataSource = bll.GetAdmin();

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

        }
    }
}
