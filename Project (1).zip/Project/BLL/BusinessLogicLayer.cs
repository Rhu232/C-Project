﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DLL;
using System.Data;

namespace BLL
{
    public class BusinessLogicLayer
    {    
        DataAccessLayer dal = new DataAccessLayer();
        public int InsertPropertyType(PropertyType propertyType)
        {
            return dal.InsertPropertyType(propertyType);
        }
        public DataTable GetPropertyType()
        {
            return dal.GetPropertyType();
        }
        public int InsertProperty(Property property)
        {
            return dal.InsertProperty(property);
        }
        public int UpdateProperty(Property property)
        {
            return dal.UpdateProperty(property);
        }
        public int DeleteProperty(Property property)
        {
            return dal.UpdateProperty(property);
        }
        public DataTable GetProperty()
        {
            return dal.GetProperty();
        }
        public int InsertProvice(Province province)
        {
            return dal.InsertProvince(province);
        }
        public DataTable GetProvice()
        {
            return dal.GetProvice();
        }
        public DataTable GetAgency()
        {
            return dal.GetAgency();
        }
        public int InsertAgency(Agency agency)
        {
            return dal.InsertAgency(agency);

        }
        public int DeleteAgency(Agency agency)
        {
            return dal.DeleteAgency(agency);
        }
        public int InsertAgent(Agent1 agent)
        {
            return dal.InsertAgent(agent);
        }
        public int UpdateAgent(Agent1 agent)
        {
            return dal.UpdateAgent(agent);
        }

        public int DeleteAgent(Agent1 agent)
        {
            return dal.DeleteAgent(agent);
        }
        public DataTable GetAgent()
        {
            return dal.GetAgent();
        }
        public int InsertTenant(Tenant tenant)
        {
            return dal.InsertTenant(tenant);
        }
        public int UpdateTenant(Tenant tenant)
        {
            return dal.UpdateTenant(tenant);
        }
        public int DeleteTenant(Tenant tenant)
        {
            return dal.DeleteTenant(tenant);
        }
        public DataTable GetTenant()
        {
            return dal.GetTenant();
        }
        public int InsertProprtyAgent(PropertyAgent propertyAgent)
        {
            return dal.UpdatePropertyAgent(propertyAgent);
        }
        public int UpdatePropertyAgent(PropertyAgent propertyAgent)
        {
            return dal.UpdatePropertyAgent(propertyAgent);
        }
        public DataTable GetPropertyAgent()
        {
            return dal.GetPropertyAgent();
        }
        public DataTable GetRental()
        {
            return dal.GetRental();
        }
        public DataTable LoginAdmin(string Email, string Password)
        {
            return dal.LoginAdmin(Email, Password);
        }
        public DataTable LoginTenant(string Email, string Password)
        {
            return dal.LoginTenant(Email, Password);
        }
        public DataTable LoginAgent(string Email, string Password)
        {
            return dal.LoginAgent(Email, Password);
        }
        public int InsertAdmin(Admin admin)
        {
            return dal.InsertAdmin(admin);
        }
        public DataTable GetAdmin()
        {
            return dal.GetAdmin();
        }
        public int SoftAgent(int agentID)
        {
            return dal.SoftAgent(agentID);
        }
        public DataTable Amount(Property prop)
        {
            return dal.GetAmount(prop);
        }
        public int InsertSurbub(Surbub surbub)
        {
            return dal.InsertSurbub(surbub);
        }
        public DataTable GetSurbub()
        {
            return dal.GetSurbub();
        }
        public int InsertCity(City city)
        {
            return dal.InsertCity(city);
        }
        public DataTable GetCity()
        {
            return dal.GetCity();
        }
        //Reports
        
        public DataTable Records(Admin ad, Tenant Tn, Agent1 ag)
        {
            return dal.GetAllRecords(ad, Tn, ag);
        }
        public DataTable UserType(Admin ad, Tenant Tn, Agent1 ag)
        {
            return dal.GetUserType(ad, Tn, ag);
        }
        public DataTable PropType(Property prop, PropertyType Pty)
        {
            return dal.GetPropType(prop, Pty);
        }
        public DataTable CiProSub(City ci, Province Prov, Surbub sub)
        {
            return dal.GetCityProSub(ci, Prov, sub);
        }
        public DataTable AgentReport(Tenant tn, Agent1 ag)
        {
            return dal.GetAgentReports(tn, ag);
        }
        public DataTable EndedDate(Rental Ren)
        {
            return dal.GetEndedDates(Ren);
        }
        public DataTable GetAmount(Property prop)
        {
            return dal.GetAmounts(prop);
        }
        public DataTable GetOverTime(Tenant Tn, Property Prop, Rental ren)
        {
            return dal.GetOverTime(Tn, Prop, ren);
        }
        public DataTable GetAgency(Agency Ag)
        {
            return dal.Agency(Ag);
        }
        public DataTable GetActive(Admin ad, Agent1 ag)
        {
            return dal.GetActive(ad, ag);
        }

        public int InsertRental(Rental rental)
        {
            return dal.InsertRental(rental);

        }
        public int UpdateRental(Rental rental)
        {
            return dal.UpdateRental(rental);
        }
        public DataTable GetRental()
        {
            return dal.GetRental();
        }
    }
}
